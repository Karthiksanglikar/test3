package com.test3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Test3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
